<?php 
  require 'secureauthentication.php';
?>
<h2> Welcome <?php echo $_POST['username']; ?> !</h2>
<a href="logout.php">Logout</a> 
