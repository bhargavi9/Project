<?php 
  session_start();
  session_destroy();
?>
<p> You are logout! </p>

<a href="form.php">Login again</a> 

