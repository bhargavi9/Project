<?php
//  echo "->auth.php";

  ini_set("session.cookie_httponly", True); //new

  ini_set("session.cookie_secure", True); //new

 

  session_start();

 



  require 'mysql.php';

  if (isset($_POST["username"]) and isset($_POST["password"]) ){

    //echo "->auth.php:Debug>has username/password";

    if (mysql_checklogin_secure($_POST["username"],$_POST["password"])) {      

	$_SESSION["logged"] = TRUE;
    $_SESSION["browser"] = $_SERVER["HTTP_USER_AGENT"];

  }

    else{

                   echo "<script>alert('Invalid username/password');</script>";

                   unset($_SESSION["logged"]);

    }

  }

  if (!isset($_SESSION["logged"] ) or $_SESSION["logged"] != TRUE) {

    echo "<script>alert('You have not login. Please login first');</script>";

    //echo "->auth.php:Debug>You have not login. Please login first";

    header("Refresh:0; url=form.php");

    //header( 'Location: form.php' ) ;

    die();

  }

  if ($_SESSION["browser"] != $_SERVER["HTTP_USER_AGENT"]){

  echo "<script>alert('Session hijacking is detected!');</script>";

  header("Refresh:0; url=form.php");

    //header( 'Location: form.php' ) ;

    die();

}


?>
