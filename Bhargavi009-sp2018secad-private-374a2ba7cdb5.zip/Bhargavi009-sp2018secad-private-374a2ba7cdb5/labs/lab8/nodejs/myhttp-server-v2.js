var http = require("http");
var server = http.createServer(function(request,response){
console.log("Got a request: " + request.url);
response.writeHead(200);
 var fs = require("fs"); //file system module
 var fileStream = fs.createReadStream('./client.html');
 fileStream.pipe(response);
response.write("Hello");
response.end();
});
var port = 3000;
server.listen(port);
console.log("Server is running at port: " + port);
