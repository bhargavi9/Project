var http = require("http");
var server = http.createServer(function(request,response){
console.log("Got a request: " + request.url);
response.write("Hello");
response.end();
});
var port = 3000;
server.listen(port);
console.log("Server is running at port: " + port);
