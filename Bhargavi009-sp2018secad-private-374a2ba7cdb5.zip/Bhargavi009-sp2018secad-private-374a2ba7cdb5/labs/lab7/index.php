<?php 
  require 'secureauthentication.php';
?>
Welcome <?php echo htmlspecialchars($_SESSION['username']); ?>
<a href="changepasswordform.php">Change	password</a>	
<a href="logout.php">Logout</a> 
