<?php
	session_start(); 
if (isset($_POST["username"]) and isset($_POST["password"]) ){
    //echo "->auth.php:Debug>has username/password";
    if (checklogin($_POST["username"],$_POST["password"])) 
      $_SESSION["logged"] = TRUE;
    else{
	     echo "<script>alert('Invalid username/password');</script>";

	     unset($_SESSION["logged"]); 
    }
  }
if (!isset($_SESSION["logged"] ) or $_SESSION["logged"] != TRUE) {
    echo "<script>alert('You have not login. Please login first');</script>";
    //echo "->auth.php:Debug>You have not login. Please login first";
    header("Refresh:0; url=form.php");
    //header( 'Location: form.php' ) ;
    die();
  }
?>
  
<h2> Welcome <?php echo $_POST['username']; ?> !</h2> 
<?php	
	function checklogin($username, $password) {
		$account = array("admin","1234");
		if (($username== $account[0]) and ($password == $account[1])) 
		  return TRUE;
		else return FALSE;
  	}

?>



