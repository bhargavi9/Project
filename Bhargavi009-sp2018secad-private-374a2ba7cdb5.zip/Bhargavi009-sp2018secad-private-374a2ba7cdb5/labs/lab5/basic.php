<!DOCTYPE html>

<html>

<body>

<?php

echo "Welcome to my PHP test page!<br>"; // generate test to HTML page

$x = 'SecAD Spring'; # variables must start with $ and case-sensitive

$y = 2018; //no type declaration for variables 

/* PHP keywords are NOT case-sensitive */

PrInt "From $x " . $y . '<br>'; 

?>

</body>

</html>


