<?php
include 'header.php';
require 'usersql.php';
?>
<h2> My Blog!</h2>
<div align="right">
<a href="index.php">Home</a>|
<a href="adminform.php">Admin</a>|
<a href="userform.php">User</a>  
</div>
<br>
<h2>Welcome</h2>
<hr>
<h3 align="center">Welcome to my blog. Leave a comment if you like the new design :-)</h3>
<h3>Be the first to comment</h3>
<br>
<h2>Test</h2>
<hr>
<h3 align="center">Is it working?</h3>
<h3>Be the first to comment</h3>
<h3 align="center">No Copyright</h3>
<?php
show_index();
?>



