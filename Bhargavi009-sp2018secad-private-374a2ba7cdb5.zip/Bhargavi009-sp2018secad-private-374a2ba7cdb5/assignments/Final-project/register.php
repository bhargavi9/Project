<!DOCTYPE html>
<html>
<head>
<style>
 body{
	font-size: 24px;
	font-family: "Arial", Helvetica, sans-serif;    
	background: linear-gradient(to right, rgba(255,0,0,0), rgba(255,0,0,1)); 
     }
button{
	    font-size: x-large;
            margin: 8px;
}
</style>
</head>
	

      <h2 align="center">Registration Page</h2>
      <h3 align="right"><a href="index.php">Home</a></h3>

<br>

<?php
  //some code here

  require 'mysql.php';
  $newusername = $_REQUEST['newusername'];
  $newpassword = $_REQUEST['newpassword'];
  $name = $_REQUEST['name'];
  $email = $_REQUEST['email'];
  $phone = $_REQUEST['phone'];


  if (isset($newusername) and isset($newpassword) and isset($name) and isset($email) and isset($phone))
  
  {

    
           if (newuserregistration($newusername, $newpassword, $name, $email ,$phone))
		       {
                  echo "Success!";
               }
		else
			   {
                 echo "Failed!";
               }
   } 
   
   else
   {
      echo "Enter your Details to Register:";
   }
?>
<br>
<?php
  echo "Current time: " . date("Y-m-d h:i:sa")
?>
<br>
<center>
          <form action="newuser.php" method="POST" class="form login">
                Username: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" class="text_field" name="username" 
				required pattern="\w+" title="please enter a valid username" onchange="this.setCustomValidity(this.validity.patternMismatch ? this.title:'');"/> <br>
                Password: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="password" class="text_field" name="password" required pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}"																	
		title="Password	must has at least 6 characters with atleast one number,one lowercase and 1 						         uppercase"								
		onchange="this.setCustomValidity(this.validity.patternMismatch?this.title:'');"/> <br>
		Name:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="name" class="text_field" required pattern="\w+"/> <br/>
		Email: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="email" name="email" title="xxx@gmail.com" pattern="[^ @]*@[^ @]*" placeholder="username@gmail.com"><br>
		Telephone: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='tel' name="phone" pattern='[\+]\d{2}[\(]\d{2}[\)]\d{4}[\-]\d{4}' placeholder="+xx(xx)xxxx-xxxx" title='Phone Number (Format:+11(11)1111-1111)'>
<br>	
                <button formaction="newuser.php" class="button" type="submit">
                  click to Register
                </button>
          </form>
</center>
  </html>



