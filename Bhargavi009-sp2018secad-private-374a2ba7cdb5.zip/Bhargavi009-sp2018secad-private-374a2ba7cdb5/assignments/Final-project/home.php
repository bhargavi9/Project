<html>
<h2>Login</h2>
      <h1>Login</h1>
<?php
echo "Current time: " . date("Y-m-d h:i:sa")
?>
          <form action="admin.php" method="POST" class="form login">
	                  Username:
		<input type="text" class="text_field" name="username"
		 required pattern="\w+" 
		title="Username must be a word"
		onchange="this.setCustomValidity(this.validity.patternMismatch?this.title: '');">
				<br>
                Password: <input type="password" class="text_field" name="password" /> <br>
		<a href="form.php"><input type="radio" name="admin" value="form.php">Admin</input></a>
		<a href="register.php"><input type="radio" name="admin" value="register.php">User</input></a>
		 <button class="button" type="submit">
                  Login
                </button>
          </form>
  </html>
