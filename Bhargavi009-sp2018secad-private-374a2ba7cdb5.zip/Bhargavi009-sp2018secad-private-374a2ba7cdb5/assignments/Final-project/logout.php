<?php 
  session_start();
  session_destroy();
?>
<p> You are logged out! </p>
<a href="index.php">Login again</a> 


