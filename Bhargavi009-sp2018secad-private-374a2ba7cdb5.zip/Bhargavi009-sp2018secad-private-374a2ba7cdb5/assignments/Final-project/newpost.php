<?php
session_start();
require 'usersql.php';
$username=$_SESSION["username"];
$kl = $_REQUEST["p"];
$ti = $_SESSION["nocsrftoken2"];
//echo $kl;
//echo "token";
//echo $ti;
if (!isset($ti) or ($ti != $_SESSION['nocsrftoken2'])) {
    echo "Cross-site request forgery is	detected!";
    die();
}
function handle_new_post() {
    $title = $_POST['title'];
    $text = $_POST['text'];
    $owner = $_POST['owner'];
    
    echo "text =" . $text;
    echo "title=" . $title;
    if (isset($title) and isset($text) and isset($owner)) {
        if (new_post($title, $text, $owner)) echo "New Post Updated";
        else echo "New post is not added";
    }
}
handle_new_post();
?>
<a href="users.php">User Page</a>|
<form action="newpost.php" method="POST" class="form post">
	
	User: <input type="text" name = "owner" value= "<?php echo $username; ?>" /> 
	Title:<input type="text" name="title" /> <br>
	text: <textarea name="text" required cols="100" rows="10"></textarea><br>
	<button class="button" type="submit">
		Post new comment
	</button>
	</form>
