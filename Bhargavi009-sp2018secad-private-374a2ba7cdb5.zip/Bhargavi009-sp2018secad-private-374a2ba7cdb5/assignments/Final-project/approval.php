<?php
require 'adminsql.php';
$approved = $_REQUEST['approved'];
$enabled = $_REQUEST['enabled'];
$username = $_REQUEST['username'];
echo "approved---" . $approved;
echo "Enabled......" . $enabled;
echo "username:----" . $username;
if (isset($approved)) {
    if ($approved == 1) {
        if (isset($enabled)) {
            if (approv($username, $approved, $enabled)) {
                echo "Success!";
            } else {
                echo "Failed!";
            }
        }
    } else {
        del($username);
    }
} else {
    echo "Cannot approve";
}
?>
