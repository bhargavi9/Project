<?php 
  require 'userauthentication.php';
?>

<html>
<head>
<h2> Administration of  my blog!</h2>
<div align="right">
<a href="index.php">Home</a>|
<a href="newpost.php">New Post</a>|
<a href="editprofile.php">Edit Profile</a>|
<a href="changepasswordform.php">ChangePassword</a>|
<a href="logout.php">Logout</a>
</div>
<?php
//require 'mysql.php';
$rand = bin2hex(openssl_random_pseudo_bytes(16));
$_SESSION["nocsrftoken2"] = $rand;
$username=$_SESSION["username"];
echo 'Welcome-----';
echo $username;
$sql = "SELECT * FROM posts where owner= '".$username."'";
$result = $mysqli->query($sql);
if ($result->num_rows > 0) {
    //List of comments
    while ($row = $result->fetch_assoc()) {
        $postid = $row["id"];
        echo '<table border="1" align="center">';
	echo "<form action='enableuser.php?postid=".$postid."' method='POST'>";
	echo '<th>Username</th>';
	echo '<th>Edit Comment</th>';	
	echo '<th>Delete Comment</th>';
	echo '<th>Enable/Disable</th>';
        echo '<tr>';
        echo '<td>';
        echo "<h3>" . $row["title"] . "</h3>";
        echo '</td>';
        echo '<td>';
        echo '<a href ="edit.php?postid=' . $row['id'] . '">' . "edit" . '</a>';
        echo '</td>';
        echo '<td>';
        echo '<a href ="delete.php?postid=' . $row['id'] . '">' . "delete" . '</a>';
        echo '</td>';
	echo "<td>
		<input type='radio' name='enabled' value=1 "; if($enabled==1){echo "checked";}echo">enable<br>
		<input type='radio' name='enabled' value=0 "; if($enabled==0){echo "checked";}echo">disable<br>
	</td>";
	echo '<td>';
	echo '<input type="submit" name ="submit" value="submit"/>';
	echo '</td>';
	echo '</tr>';
	echo '</form>';
        echo '</table>';
    }

}
?>
<div align="center">
<a href="newpost.php?p=<?php echo $rand ?>">Write a new post</a>
</div>
</head>
</html>
