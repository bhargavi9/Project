<?php
require 'secureauthentication.php';
?>
<html>
<h2> Administration of my blog!</h2>
<div align="right">
<a href="index.php">Home</a>|
<a href="changepasswordformadmin.php">ChangePassword</a>|
<a href="logout.php">Logout</a>
</div>
<?php
//require 'adminsql.php';
$sql = "SELECT username FROM newregisters";
$result = $mysqli->query($sql);
if ($result->num_rows > 0) {
    //List of comments
    while ($row = $result->fetch_assoc()) {
        $username = $row["username"];
        $approved = $row["approved"];
        $enabled = $row["enabled"];
        echo '<table border="1" align="center">';
        echo "<form action='approval.php?username=" . $username . "' method='POST'>";
        echo '<th>Username</th>';
        echo '<th>Approval/Disapprove</th>';
        echo '<th>Enable/Disable</th>';
        echo '<tr>';
        echo '<td>';
        echo "<h3>" . $row["username"] . "</h3>";
        echo '</td>';
        echo "<td>
		<input type='radio' name='approved' value=1 ";
        if ($approved == 1) {
            echo "checked";
        }
        echo ">Approve<br>
		<input type='radio' name='approved' value=0 ";
        if ($approved == 0) {
            echo "checked";
        }
        echo ">disapprove<br>
	</td>";
        echo "<td>
		<input type='radio' name='enabled' value=1 ";
        if ($enabled == 1) {
            echo "checked";
        }
        echo ">enable<br>
		<input type='radio' name='enabled' value=0 ";
        if ($enabled == 0) {
            echo "checked";
        }
        echo ">disable<br>
	</td>";
        echo '<td>';
        echo '<input type="submit" name ="submit" value="submit">';
        echo '</td>';
        echo '</tr>';
        echo '</form>';
    }
    echo '</table>';
}
?>
<br>
<br>
<br>

</html>
