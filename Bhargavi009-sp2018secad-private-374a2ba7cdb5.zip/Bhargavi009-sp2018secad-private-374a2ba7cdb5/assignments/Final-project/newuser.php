<?php 
  require 'mysql.php';
  $username = $_REQUEST['username'];
  $password = $_REQUEST['password'];
  $name = $_REQUEST['name'];
  $email = $_REQUEST['email'];
  $phone = $_REQUEST['phone'];

 if (isset($username) and isset($password) and isset($name) and isset($email) and isset($phone))
  
  {

    
           if (newu($username, $password, $name, $email ,$phone))
		       {
                  echo "Success!";
               }
		else
			   {
                 echo "Failed!";
               }
   } 
   
   else
   {
      echo "Cannot change password: username and password is not provided";
   }
?>
<a href="userform.php">login page </a>
