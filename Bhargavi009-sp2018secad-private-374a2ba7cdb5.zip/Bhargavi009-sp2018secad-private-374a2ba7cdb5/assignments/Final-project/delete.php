<?php
session_start();
require 'userauthentication.php';
//require 'usersql.php';
$id = $_REQUEST['postid'];

$sql="select *from posts where id='$id';";
$result = $mysqli -> query($sql);
$row=$result->fetch_assoc();
$username=$row['owner'];
if($username!=$_SESSION['username'])
{
echo "cannot Delete.....";
die();
}



if (delete_post($id)) echo "Post Deleted";
else echo "Post not Deleted";
?>
