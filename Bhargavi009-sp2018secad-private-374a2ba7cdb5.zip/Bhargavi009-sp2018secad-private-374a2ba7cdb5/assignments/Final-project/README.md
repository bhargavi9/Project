##Final-Project

Initially we need to pull the folders from the git repository

Secondly, we need to push the folder to the web repository to check the functionality of the application

Walkthrough of the application:

index.php:
The index page is the homepage of the application
The homepage contains the enabled posts of the approved users.
The following screenshot illustrates the view of the home page:

index.php: It contains the home page interface and also displays the posts enabled by the user.
database.sql: It contains all the tables created under the database.

The application contains three major parts:
1.Admin/superuser
2.Regularusers
3.NewUsers

1. Admin Pages:
1.Admin/superuser:
The Admin can approve or disapprove the users.
He can even change his password.

adminform.php: It contains the user interface of the admin with username and password fields for the admin to login.
admin.php: It contains the list of the registered users who are waiting for the approval so that the users can login after the approval.
adminsql.php: It contains the validation of the admin credentials and the sql credentials to checkout the credentials by retreiving the details from database.
secureauthentication.php: It contains the code to check if the entered admin username is the same irrespective of page refresh or when we introduce other username url with that of the http session.
changepasswordformadmin.php: It contains the userinterface of changing the password of the admin.
changepasswordadmin.php: It has the logic to change the password using the username.
approval.php: It has the logic to enable and disable the user account and even they can approve or disaprove the registered user.
logout.php: It contains the code to logout of the webpage.

2. Regular Users:
The regular users can enable or disable the posts to be displayed on the homepage so that the guests can comment on the post.
They can even edit their details which are entered during the registration.
The user can even change their passwords.
The user can create a post so that if he enables it , the posts will be displayed on the home page.
They can even edit the posts created and even delete it.

userform.php: It contains the interface with the username and password fields.
users.php: It contains the posts created by the users with edit, delete and enable posts option.
userauthentication: It contains the code to check if the entered user is the same irrespective of page refresh or when we introduce other username url with that of the http session.
changepasswordform.php: It contains the userinterface of changing the password of the user.
changepassword.php: It has the logic to change the password of the user using the username.
edit.php: It contains the logic to edit the posts created by that user.
delete.php: It contains the logic to delete the posts created by that user.
editprofile.php: It contains the logic to edit the details of the user which are stored when approved by the admin.
enableuser.php: It contains the logic to enable the posts of the user so that the posts will be displayed on the home page if enabled.
newpost.php: It contains the logic to create a newpost and insert into the database which is done by the loggedin user.
comment.php: It contains the logic to handle the new comment created by the logged in user.
mysql.php: It contains the logic to insert the posts created into the database.
logout.php: It handles the code to log out of the existing web page.

3.NewUsers:
The unregistered users need to fill the details inorder to login if the admin approves the user.
They need to wait for the admins approval

newuser.php: It contains the code to check if the details are entered and also checks if the username is not the same that of the registered users.

SSL folder:
The ssl folder contains the key and the certificate.
sp2018secad.crt: It contains the certificate of the authorization
sp2018secad.key: It contains the key value of the certificate created.



