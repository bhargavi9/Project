<?php
session_start();
require 'usersec.php';
require 'usersql.php';
$id = $_REQUEST['postid'];
$sql="select *from posts where id='$id';";
$result = $mysqli -> query($sql);
$row=$result->fetch_assoc();
$username=$row['owner'];
echo $id;
function handle_edit($id,$username) {
    $id = $_POST['postid'];
    $title = $_POST['title'];
    $newtext = $_POST['newtext'];
	if($username!=$_SESSION['username'])
{
echo "cannot edit.....";
die();
}
    if (isset($title) and isset($newtext) and isset($id)) {
        if (edit_post($id,$title,$newtext)) echo "Post Updated";
        else echo "Post not updated";
    }
}
handle_edit($id,$username);
?>
<html>
<form action="edit.php" method="POST" class="form post">
	<input type="hidden" name="nocsrftoken" value="<?php echo $rand; ?>"/>
        <input type="hidden" name="postid" value="<?php echo $id; ?>"/>
	Title:<input type="text" name="title" value="<?php echo $title; ?>"/> <br>
	content: <textarea name="newtext" required cols="100" rows="1"></textarea><br>
	<button class="button" type="submit">
		EDIT POST
	</button>

	</form>
<a href="users.php">User Page</a>
</html>
