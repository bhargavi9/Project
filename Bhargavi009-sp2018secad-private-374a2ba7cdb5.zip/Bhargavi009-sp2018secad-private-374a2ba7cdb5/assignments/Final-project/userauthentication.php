<?php

ini_set("session.cookie_httponly", True); //new
ini_set("session.cookie_secure", True); //new  

  session_start();
 // void session_set_cookie_params(int $lifetime[,string $path[,string $domain[,bool $secure=false[,bool $httponly=false]]]])
  echo "->auth.php";
  require 'usersql.php';
  if (isset($_POST["username"]) and isset($_POST["password"]) ){
    //echo "->auth.php:Debug>has username/password";
    if (mysql_checklogin_secure($_POST["username"],$_POST["password"])) {
      $_SESSION["logged_user"] = TRUE;
	$_SESSION["browser"] = $_SERVER["HTTP_USER_AGENT"];
	$_SESSION["username"] = $_POST["username"];
    }
    else{
	     echo "<script>alert('Invalid username/password');</script>";
	     unset($_SESSION["logged_user"]); 
    }
}
if (!isset($_SESSION["logged_user"] ) or $_SESSION["logged_user"] != TRUE) {
    echo "<script>alert('You have not login. Please login first');</script>";
    //echo "->auth.php:Debug>You have not login. Please login first";
    header("Refresh:0; url=userform.php");
    //header( 'Location: form.php' ) ;
    die();
  }

if ($_SESSION["browser"] != $_SERVER["HTTP_USER_AGENT"]){
 echo "<script>alert('session hijacking is detected!');</script>";
header("Refresh:0; url=userform.php");
  die();
}

?>
