<?php 

ini_set("session.cookie_httponly", True); //new
ini_set("session.cookie_secure", True); //new  

  session_start();

if (!isset($_SESSION["logged_user"] ) or $_SESSION["logged_user"] != TRUE) {
    echo "<script>alert('You have not login. Please login first');</script>";
    //echo "->auth.php:Debug>You have not login. Please login first";
    header("Refresh:0; url=userform.php");
    //header( 'Location: form.php' ) ;
    die();
  }

if ($_SESSION["browser"] != $_SERVER["HTTP_USER_AGENT"]){
 echo "<script>alert('session hijacking is detected!');</script>";
header("Refresh:0; url=userform.php");
  die();
}
?>
