<?php
session_start();
require 'userauthentication.php';
//require 'usersql.php';
$username = $_SESSION['username'];
$newpassword = $_REQUEST['newpassword'];
$nocsrftoken = $_POST["nocsrftoken"];

if (!isset($nocsrftoken) or ($nocsrftoken != $_SESSION['nocsrftoken'])) {
    echo "Cross-site request forgery is	detected!";
    die();
}
if (isset($_SESSION["username"]) and isset($newpassword)) {
    /* if ($username != $_SESSION["username"]) {
    echo "Cannot .......";
        echo "Cannot change password: '" . $_SESSION["username"] . "' CANNOT change password for '$username'";
        die();
    }*/
    echo "Change password for '" . $_SESSION["username"] . "'";
    if (mysql_change_users_password($username, $newpassword)) {
        echo "Success!";
    } else {
        echo "Failed!";
    }
} else {
    echo "Cannot change password: username and password is not provided";
}
?>
<h2> Authenticated and active session!</h2>
<a href="index.php">Admin page </a> | <a href="logout.php">Logout</a>

