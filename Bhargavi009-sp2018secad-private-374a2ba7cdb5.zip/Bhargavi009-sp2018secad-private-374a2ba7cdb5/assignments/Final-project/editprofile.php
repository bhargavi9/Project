<?php
session_start();
//require 'userauthentication.php';
require 'usersql.php';
$username = $_SESSION['username'];
echo $username;
function handle_details() {
   $username = $_POST['username'];
    $name=$_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    if (isset($username) and isset($name) and isset($email) and isset($phone)) {
        if (edit_details($username,$name,$email,$phone)) echo "Details Updated";
        else echo "Details not updated";
    }
}
handle_details();
?>

<html>
<form action="editprofile.php" method="POST" class="form login">

<input type="hidden" name="username" value="<?php echo $username; ?>"/>
	Name:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="name" class="text_field" required pattern="\w+"/> <br/>
		Email: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="email" name="email" pattern="[^ @]*@[^ @]*" placeholder="username@gmail.com"><br>
		Telephone: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='phone' name="phone" pattern='[\+]\d{2}[\(]\d{2}[\)]\d{4}[\-]\d{4}' placeholder="+xx(xx)xxxx-xxxx" title='Phone Number (Format:+11(11)1111-1111)'>
	<button class="button" type="submit">
		EDIT Details
	</button>

	</form>
<a href="users.php">User Page</a>
</html>
