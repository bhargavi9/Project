<?php 
  require 'usersql.php';
  
  $userenabled = $_SESSION['enabled'];
  $id = $_SESSION['postid'];
 
  echo "id:----".$id;
 if (isset($userenabled)==1 )
  
  {
    if (show_enable($id,$userenabled))
		       {

                  echo "Success!";
               }
		else
			   {
                 echo "Failed!";
               }


}
?>
