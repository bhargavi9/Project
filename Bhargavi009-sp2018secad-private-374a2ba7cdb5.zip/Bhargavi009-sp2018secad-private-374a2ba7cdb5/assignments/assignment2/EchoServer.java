/*
 * Copyright (c) 2013, Oracle and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   - Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 *   - Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 *   - Neither the name of Oracle or the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
 * IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

import java.net.*;
import java.io.*;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.*;
import java.lang.*;
//import java.io.Console;


public class EchoServer {
 static ThreadList threadlist = new ThreadList();
 public static void main(String[] args) throws IOException {

  if (args.length != 1) {
   System.err.println("Usage: java EchoServer <port number>");
   System.exit(1);
  }

  int portNumber = Integer.parseInt(args[0]);

  try {
   ServerSocket serverSocket =
    new ServerSocket(Integer.parseInt(args[0]));
   System.out.println("EchoServer is running at port " + Integer.parseInt(args[0]));


   while (true) {
    Socket clientSocket = serverSocket.accept();
    System.out.println("A client is connected ");
    EchoServerThread newthread = new EchoServerThread(threadlist, clientSocket);
    //addthread1 will strore the newthread in an arraylist
    threadlist.addThread1(newthread);
    newthread.start();

   }


  } catch (IOException e) {
   System.out.println("Exception caught when trying to listen on port " + portNumber + " or listening for a connection");
   System.out.println(e.getMessage());
  }
 }
}

class EchoServerThread extends Thread {
 private Socket clientSocket = null;
 ThreadList threadlist = null;
 private PrintWriter out = null;
 //private Console console=new Console();
 //To store username
 String username;

 public EchoServerThread(Socket socket) {
  clientSocket = socket;
 }



 public EchoServerThread(ThreadList threadlist, Socket socket) {
  this.threadlist = threadlist;
  clientSocket = socket;
 }


 public void run() {
  System.out.println("A new thread for client is running, number of connected clients:");

  //Check if threadlist is not empty i.e; has clients connected			
  if (threadlist != null)
   System.out.println("Inside thread: total clients:" + threadlist.getNumberofThreads());
  //if the thread is empty return empty
  else {
   System.out.println("Thread is empty...");
   send("Thread is empty...");
   try {
    clientSocket.close();
   } catch (IOException ioe) {
    System.out.println("Exception in thread:" + ioe.getMessage());
   }
   return;
  }
  try {

   //Acts as a flag variable
   int
   var = 0;

   out =
    new PrintWriter(clientSocket.getOutputStream(), true);
   BufferedReader in = new BufferedReader(
    new InputStreamReader(clientSocket.getInputStream()));



   String inputLine, option;

   /*send("Enterusername:\n");
   username=in.readLine();
   send("EnterPassword:\n");
   password=in.readLine();

   //*/

   send("To All: the number of connected client:" + threadlist.getNumberofThreads());
   //Here we check if the user log in with correct credentials and exit him after checking the credentials
   while (var == 0) {

    /*if(((username.equals("Bhargavi007")))&&((password.equals("Bhargavi009")))){
    send("Successfully Logged in....");
    System.out.println("Successfully Logged in....");*/

    if (((inputLine = in .readLine()) != null)) {
     //Stores the options:invalid,exist,wrongpassword,exit and does the action accordingly
     option = threadlist.Authenticate(inputLine);
     //If the user authentication fails send the message and close the connection
     if (option.equals("Invalid")) {
      System.out.println("You have not login. To login, use <JOIN>username:password ");
      send("You have not login. To login, use <JOIN>username:password");
      var = 0;
     }
     //If the user already login and is trying to redo the login then send the message
     else if (option.equals("Exist")) {
      System.out.println("User exists and already logged in");
      send("User exists and already logged in");
      var = 0;
     }
     //If he fails to give correct password then show the correct sytanx to login
     else if (option.equals("wrongpassword")) {
      System.out.println("Wrong password.. to Login use:<JOIN>username:password | to exit use: <EXIT>");
      send("Wrong password.. to Login use:<JOIN>username:password | to exit use: <EXIT>");
      var = 0;
     }
     //If he wants to exit the connection then close the streams and socket connection
     else if (option.equals("EXIT")) {

      try {
       System.out.println("exiting from the connection..");
       threadlist.removeThread1(this);


       in .close();
       out.close();
       clientSocket.close();

       break;
      } catch (IOException ioe) {
       System.out.println("Exception:" + ioe.getMessage());
       send("Exception:" + ioe.getMessage());

      }
     }


     //If the user gives correct credentials then login the user with a welcome message
     else {
      username = option;
      threadlist.addThread(username, this);
      send("Welcome" + "" + username);
      var = 1;
     }
    }

    //If he fails to login then send the syntax message 
    else {

     System.out.println("To login, use <JOIN>username:password");
     send("To login, use <JOIN>username:password");
     var = 0;
    }

   }

   //Check the input after the user login with correct credentials
   while ((inputLine = in .readLine()) != null) {
    //System.out.println("received from client: " + inputLine);

    //System.out.println("Username:"+username);

    //System.out.println("Echo back");
    //out.println(inputLine);
    //If the command is exit the display the following message and close the connection
    if (inputLine.equals("<EXIT>")) {
     //threadlist.sendToAll("To All: A client"+username+" exists, the number of connected client:" + 
     //					(threadlist.getNumberofThreads()-1));
     send("To All: the number of connected client: exists, the number of connected client:" + threadlist.getNumberofThreads());
     threadlist.removeThread(username);
     threadlist.removeThread1(this);
     System.out.println("Exiting connection...");
     break;
    }


    //If the command length is greater than 6 only then the user can access the commands
    if ((inputLine.length()) >= 6) {
     String s1, s2;

     s1 = inputLine.substring(0, 6);
     s2 = inputLine.substring(6);

     //If the user wants to check the connected clients
     if (s1.equals("<LIST>")) {
      System.out.println("received from client: <LIST>");
      send(threadlist.list());
      continue;
     }

     //If he wants to chat with the users connected
     if (s1.equals("<CHAT>")) {


      System.out.println("received from client: <CHAT>" + s2);

      threadlist.sendToAll("<ALL>" + username + "<CHAT>" + s2);
      continue;
     }

     //If he wants to chat with a specific connected client
     if (s1.equals("<PRIV>")) {
      String split[] = s2.split(":");
      //If the syntax for the command priv is wrong then display the following message
      if (split.length != 2) {
       System.out.println("Bad command: please use: <PRIV>USERNAME:Message");
       send("Bad command: please use: <PRIV>USERNAME:Message");
       continue;
      }
      String user = split[0];
      inputLine = split[1];
      //If specified user is not existing then display the message
      if (!threadlist.senduser(username, user, inputLine)) {
       //System.out.println("Unable to process...");
       send("specified user is not connected or not existing");
      }
     }
     //If the user gives an invalid command
     else {
      System.out.println("received from client:" + inputLine);
      send("Bad command. Please try either <LIST> | <CHAT>Message | <PRIV>username:Message");
     }
    }
    //If the user gives an invalid command
    else {
     System.out.println("received from client:" + inputLine);
     send("Bad command. Please try either <LIST> | <CHAT>Message | <PRIV>username:Message");
    }
   }
   //Close all the connections

   in .close();
   out.close();
   clientSocket.close();
  } catch (IOException ioe) {
   System.out.println("Exception:" + ioe.getMessage());
   send("Exception:" + ioe.getMessage());
  }
 }

 //Display the message
 public void send(String message) {

  if (out != null)
   out.println(message);

 }
}


class ThreadList {
 //private ... threadlist = //store the list of threads in this variable	
 //Hashmap is to store the usernames and threads list
 private HashMap < String, EchoServerThread > threadlist = new HashMap < String, EchoServerThread > ();
 //Arraylist is to store the list of users 
 private ArrayList < EchoServerThread > threadlist1 = new ArrayList < EchoServerThread > ();
 //Hashmap to store the usernames and passwords of the existing users
 private static final HashMap < String, String > existusers = new HashMap < String, String > () {
  {

   existusers.put("Eswari007", "Eswari009");
   existusers.put("Bhargavi007", "Bhargavi009");
  }
 };



 public ThreadList() {}
  //Method to return the number of threads
 public synchronized int getNumberofThreads() {
   //return the number of current threads
   return threadlist1.size();
  }
  //add the newthread object to the threadlist	

 public synchronized void addThread(String username, EchoServerThread newthread) {

  threadlist.put(username, newthread);

 }

 //add the newthread object to the threadlist1
 public synchronized void addThread1(EchoServerThread newthread) {


   threadlist1.add(newthread);

  }
  //remove the given thread from the threadlist
 public synchronized void removeThread(String username) {

   threadlist.remove(username);

  }
  //remove the given thread from the threadlist1	
 public synchronized void removeThread1(EchoServerThread newthread) {

  threadlist1.remove(newthread);

 }


 //Authenticating the user , the username and password are separated by ":" and also verifying the command typed is valid
 String Authenticate(String input) {


  if (input.equals("<EXIT>"))
   return "EXIT";

  if (input.length() >= 6) {
   String s1 = input.substring(0, 6);
   String s2 = input.substring(6);
   if (s1.equals("<JOIN>")) {
    String split[] = s2.split(":");
    if (split.length != 2) {
     return "Invalid";
    }
    String username = split[0];
    String password = split[1];
    //If username exists and password doesnt match
    if (existusers.containsKey(username)) {
     if (!existusers.get(username).equals(password)) {
      //If the password is wrong
      return "wrongpassword";

     }

     if (threadlist.containsKey(username)) {
      //If the user is valid
      return "Exist";
     } else {
      return username;
     }
    }
   }
  }
  return "Invalid";
 }

 //Sending message to particular user if the user exists in "priv" command
 public boolean senduser(String username, String user, String msg) {
  if (threadlist.containsKey(user)) {
   threadlist.get(user).send("<ALL>" + username + ":<PRIV>" + user + ":" + msg);
   threadlist.get(user).send("To All: the number of connected client:" + getNumberofThreads());
   System.out.println("Received from client: <PRIV>" + user + ":" + msg);
   return true;
  }
  return false;
 }


 public void sendToAll(String message) {
  //ask each thread in the threadlist to send the given message to its client
  for (EchoServerThread thread: threadlist.values())

  {
   thread.send(message);
  }
 }


 public String list() {
  String msg = "";

  for (String user: threadlist.keySet()) {

   msg = msg + user + "";

  }

  return msg;
 }


}
