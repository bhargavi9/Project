<?php
session_start();
require 'mysql.php';
$id = $_REQUEST['postid'];
if (delete_post($id)) echo "Post Deleted";
else echo "Post not Deleted";
?>
