<html>
<head>
<h2> Administration of  my blog!</h2>
<div align="right">
<a href="index.php">Home</a>|
<a href="newpost.php">New Post</a>|
<a href="edit.php">Manage Post</a>|
<a href="logout.php">Logout</a>
</div>
<?php
require 'mysql.php';
$sql = "SELECT * FROM posts";
$result = $mysqli->query($sql);
if ($result->num_rows > 0) {
    //List of comments
    while ($row = $result->fetch_assoc()) {
        $postid = $row["id"];
        echo '<table align="center">';
        echo '<tr>';
        echo '<td>';
        echo "<h3>" . $row["title"] . "</h3>";
        echo '</td>';
        echo '<td>';
        echo '<a href ="edit.php?postid=' . $row['id'] . '">' . "edit" . '</a>';
        echo '</td>';
        echo '<td>';
        echo '|<a href ="delete.php?postid=' . $row['id'] . '">' . "delete" . '</a>';
        echo '</td>';
        echo '</tr>';
        echo '</table>';
    }
}
?>
<div align="center">
<a href="newpost.php">Write a new post</a>
</div>
</head>
</html>
