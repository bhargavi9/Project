<?php
session_start();
require 'mysql.php';
$postid = $_REQUEST['postid'];
if (!isset($postid)) {
    echo "Bad Request";
    die();
}
function handle_new_comment($postid) {
    $title = $_POST['title'];
    $content = $_POST['content'];
    $commenter = $_POST['commenter'];
    $nocsrftoken = $_POST["nocsrftoken"];
    $sessionnocsrftoken = $_SESSION["nocsrftoken"];
    if (isset($title) and isset($content)) {
        if (!isset($nocsrftoken) or ($nocsrftoken != $sessionnocsrftoken)) {
            echo "Cross-site request forgery is detected!";
            die();
        }
        if (new_comment($postid, $title, $content, $commenter)) echo "New comment added";
        else echo "Cannot add the comment";
    }
}
handle_new_comment($postid);
display_singlepost($postid);
display_comments($postid);
$rand = bin2hex(openssl_random_pseudo_bytes(16));
$_SESSION["nocsrftoken"] = $rand;
?>
<h2>My Blog!</h2>
<div align="right">
<a href="index.php">Home</a>|
<a href="admin.php">Admin</a>
</div>
<h2>Welcome</h2>
<hr>
<h3>Welcome to my blog. Leave a comment if you like the new design :-)</h3>
<br>
<h2>Comments:</h2>
<form action="comment.php?postid=<?php echo $postid; ?>" method="POST" class="form login">
  <input type="hidden" name="nocsrftoken" value="<?php echo $rand; ?>" />
  Your Name : <input type="text" name="commenter" /><br>
  Title : <input type="text" name="title" required/><br>
  Content : <textarea name="content" required cols="100" rows="10"></textarea><br>
  <button class="button" type="submit">submit</button>
</form>
<h4 align="center">No Copyright</h4>
