<?php
session_start();
require 'mysql.php';
function handle_new_post() {
    $title = $_POST['title'];
    $text = $_POST['text'];
    echo "text =" . $text;
    echo "title=" . $title;
    if (isset($title) and isset($text)) {
        if (new_post($title, $text)) echo "New Post Updated";
        else echo "New post is not added";
    }
}
handle_new_post();
?>
<form action="newpost.php" method="POST" class="form post">
	<input type="hidden" name="nocsrftoken" value="<?php echo $rand; ?>"/>
	Name:<input type="text" name="owner" /> <br>
	Title:<input type="text" name="title" /> <br>
	text: <textarea name="text" required cols="100" rows="10"></textarea><br>
	<button class="button" type="submit">
		Post new comment
	</button>
	</form>
