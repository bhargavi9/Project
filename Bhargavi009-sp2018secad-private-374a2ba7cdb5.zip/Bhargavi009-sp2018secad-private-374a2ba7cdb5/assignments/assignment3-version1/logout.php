<?php 
  session_start();
  session_destroy();
?>
<p> You are logged out! </p>
<a href="form.php">Login again</a> 


