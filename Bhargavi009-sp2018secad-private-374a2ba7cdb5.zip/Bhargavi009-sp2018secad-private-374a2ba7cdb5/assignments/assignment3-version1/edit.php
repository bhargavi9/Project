<?php
session_start();
require 'mysql.php';
$id = $_REQUEST['id'];
function handle_edit($id) {
    $title = $_POST['title'];
    $content = $_POST['content'];
    if (isset($title) and isset($content)) {
        if (edit_post($title, $content, $id)) echo "Post Updated";
        else echo "Post not updated";
    }
}
handle_edit($id);
?>
<form action="edit.php?id=<?php echo $id; ?>" method="POST" class="form post">
	<input type="hidden" name="nocsrftoken" value="<?php echo $rand; ?>"/>
	Title:<input type="text" name="title" value="<?php echo $title; ?>"/> <br>
	content: <textarea name="text" required cols="100" rows="1"></textarea><br>
	<button class="button" type="submit">
		EDIT POST
	</button>
	</form>
