drop table if exists users;
create table users(username varchar(50) primary key,
password varchar(255) not null);
drop table if exists posts;
create table posts(
id int(11) primary key auto_increment,
title varchar(255) not null,
text text not null,
published datetime default null,
owner varchar(50),
foreign key(owner) references users(username) on delete cascade);
drop table if exists comments;
create table comments(
id int(11) primary key auto_increment,
title varchar(255) not null,
content text not null,
commentor varchar(255),
time datetime default null,
postid int(11),
foreign key(postid) references posts(id) on delete cascade);

