class ThreadList{
	//private ... threadlist = //store the list of threads in this variable	

private ArrayList<EchoServerThread> threadlist = new ArrayList<EchoServerThread>();

	public ThreadList(){		
	}
	public synchronized int getNumberofThreads(){
	//return the number of current threads
return threadlist.size();
	}
	public synchronized void addThread(EchoServerThread newthread){
	//add the newthread object to the threadlist	

threadlist.add(newthread);

	}
	public synchronized void removeThread(EchoServerThread thread){
	//remove the given thread from the threadlist	
threadlist.remove(thread);
	
	}
	public void sendToAll(String message){
	//ask each thread in the threadlist to send the given message to its client		
	}
}

