/* include libraries */
#include <stdio.h>
#include <stdlib.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netdb.h>
#include<string.h>

int main (int argc, char *argv[])
{
   printf("Hi terminal Bhargavi on the way........\n");
if(argc!=3)
{
printf("Usage: %s <servername> <port>\n",argv[0]);
exit(0);
}

//printf("servername= %s, port= %s\n",argv[1],argv[2]);

char *servername=argv[1];
int port=atoi(argv[2]);
printf("servername= %s, port= %d\n",servername,port);

int sockfd=socket(AF_INET,SOCK_STREAM,0);
if(sockfd<0)
{

perror("errorr....");
exit(1);
}

struct hostent *server_he;

if((server_he=gethostbyname(servername))==NULL)
{


perror("error in name");
exit(2);
}


struct sockaddr_in serveraddr;
 
bzero((char *) &serveraddr,sizeof(serveraddr));
serveraddr.sin_family=AF_INET;
bcopy((char *) server_he->h_addr,
           (char *) &serveraddr.sin_addr.s_addr,
           server_he->h_length);
serveraddr.sin_port=htons(port);

int connected=connect(sockfd, (struct sockaddr *) &serveraddr,sizeof(serveraddr));

if(connected<0)
{

perror("cannot connect to the server\n");
exit(3);

}
else
printf("connected to the server %s at port: %d\n",servername,port);

char *msg="This is a test message from client";

int byte_sent;      //=send(sockfd,msg,strlen(msg),0);


char buffer[1024];
printf("enter your message\n");
bzero(buffer,1024);
fgets(buffer,1024,stdin);
//sprintf(buffer,"GET / HTTP/1.1\r\nHOST: %s\r\n\r\n", servername);
byte_sent=send(sockfd,buffer,strlen(buffer),0);


int byte_received=recv(sockfd,buffer,1024,0);
bzero(buffer,1024);

printf("%s",buffer);
if(byte_received<0)
{
perror("error in reading");
exit(4);
}

printf("received from server %s",buffer);

close(sockfd);
}
