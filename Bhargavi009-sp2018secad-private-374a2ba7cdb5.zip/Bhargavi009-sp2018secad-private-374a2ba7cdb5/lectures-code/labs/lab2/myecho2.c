#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char * argv[]) {
    char buffer[126];
    strncpy(buffer,argv[1],sizeof(buffer));
    printf("%s\n", buffer);
}

